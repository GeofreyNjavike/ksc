Habari Boss.

Kuna mzazi amefanya malipo.

Tafadhali Thibitisha.

Regards KSC Sysytem
