 <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>KSC</h3>
              <p class="pb-3"><em>Sehemu sahihi ya kumwendeleza mwanao kimichezo na kiafya.</em></p>
              <p>
                Maweni, Mjimwema <br>
                KIGAMBONI,DSM<br><br>
                <strong>Phone:</strong>   <p><a href="tel:+255765133861">+255 765 133 861</a></p><br>
                <strong>Email:</strong><a href="mailto:graduatetz@gmail.com">graduatetz@gmail.com</a><br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="fa fa-facebook"></a>
    <a href="#" class="fa fa-twitter"></a>
    <a href="https://www.youtube.com/channel/UCKzR_v8dQlyrZ_zRMcFsQBA" class="fa fa-youtube"></a>
    <a href="https://www.instagram.com/ksc_kisota/" class="fa fa-instagram"></a>
     <a href="https://wa.me/+255712828561?text= Hello habari nahitaji kumsajili mwanangu" class="fa fa-whatsapp" style="color: #075e54;"></a>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('home')}}">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#Services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#team">Timu</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="{{ url('squard')}}">wachezaji</a></li>
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="ri-check-double-line"></i> kucheza</li>
            <li><i class="ri-check-double-line"></i> kujifunza</li>
            <li><i class="ri-check-double-line"></i> kuinteract/ujirani</li>
            </ul>
          </div>

          <

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>KSC</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://njaviketech.com/">Njavike Tech</a>
      </div>
    </div>
  </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>